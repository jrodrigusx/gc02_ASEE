# coding: utf-8

# flake8: noqa
from __future__ import absolute_import
# import models into model package
from ..models.actor import Actor
from ..models.capitulo import Capitulo
from ..models.director import Director
from ..models.pelicula import Pelicula
from ..models.serie import Serie
from ..models.temporada import Temporada
